<?php
$theme_path = parse_url(theme_path(), PHP_URL_PATH);
// Include custom functions
$functions_file = ltrim($theme_path, '/') . 'functions.php';
if (file_exists($functions_file)) {
    require_once $functions_file;
}
?>
<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<!doctype html>
<html lang="<?php echo blog_language();?>">
<head>
    <?php echo head_contents();?>
    <?php echo $metatags;?>

    <link rel="stylesheet" id="genericons-css"  href="<?php echo theme_path();?>genericons/genericons.css" type="text/css" media="all" />
    <?php
        $theme_css_file = $_SERVER['DOCUMENT_ROOT'] . $theme_path . 'css/style-' . theme_config('flavor') . ".css";
        if (file_exists($theme_css_file)):
    ?>
    <link rel="stylesheet" href="<?php echo theme_path();?>css/style-<?php echo theme_config('flavor'); ?>.css" type="text/css" media="all">
    <?php else: ?>
    <link rel="stylesheet" href="<?php echo theme_path();?>css/style.css" type="text/css" media="all">
    <?php endif;?>

    <script type="text/javascript" src="<?php echo theme_path();?>js/jquery.js" id="jquery-core-js"></script>
    <?php if (isset($p) && strpos($p->body, '<pre><code>') !== false):?>
    <script type="text/javascript" src="<?php echo theme_path();?>highlightjs/highlight.min.js" id="highlight-js"></script>
    <link rel="stylesheet" href="<?php echo theme_path();?>highlightjs/styles/default.css" type="text/css" media="all">
    <?php endif;?>
</head>
<?php
	$oviClass = '';

	if (is_index()) {
		if (isset($is_front) && config('static.frontpage') === 'true') {
                // Emidio 20251106 - added sidebar in all pages, but keeping the code
                // just in case I want to revert back to no sidebar when static content
                // same below
				// $oviClass = 'no-sidebar single';
                $oviClass = 'has-sidebar blog-layout-one-column-grid';
		} else {
			if (config('teaser.type') === 'full') {
				$oviClass = 'has-sidebar blog-layout-one-column-grid';
			} else {
				$oviClass = 'has-sidebar blog-layout-two-column-grid';
			}
		}
	} elseif (isset($is_page) || isset($is_subpage)) {
		// $oviClass = 'no-sidebar single';
        $oviClass = 'has-sidebar blog-layout-one-column-grid';
	} else {
		// $oviClass = 'has-sidebar single';
        $oviClass = 'has-sidebar blog-layout-one-column-grid';
	}

?>
<body class="centered-theme-layout <?php echo $oviClass;?> hfeed">

<?php if (facebook()) { echo facebook(); } ?>
<?php if (login()) { toolbar(); } ?>
<svg width="0" height="0" style="display: none;">
	<symbol viewBox="0 0 16 16" id="menu-toggle"><title>menu</title> <path d="M0,14h16v-2H0V14z M0,2v2h16V2H0z M0,9h16V7H0V9z"/> </symbol>
	<symbol viewBox="0 0 16 16" id="menu-close"><title>close</title> <polygon points="12.7,4.7 11.3,3.3 8,6.6 4.7,3.3 3.3,4.7 6.6,8 3.3,11.3 4.7,12.7 8,9.4 11.3,12.7 12.7,11.3 9.4,8"/> </symbol>
	<symbol viewBox="0 0 16 16" id="search"><title>search</title> <path d="M14.7,13.3L11,9.6c0.6-0.9,1-2,1-3.1C12,3.5,9.5,1,6.5,1S1,3.5,1,6.5S3.5,12,6.5,12c1.2,0,2.2-0.4,3.1-1l3.7,3.7L14.7,13.3zM2.5,6.5c0-2.2,1.8-4,4-4s4,1.8,4,4s-1.8,4-4,4S2.5,8.7,2.5,6.5z"/> </symbol>
	<symbol id="icon-twitter" viewBox="0 0 512 512"><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"/></symbol>
	<symbol id="icon-facebook" viewBox="0 0 512 512"><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"/></symbol>
	<symbol viewBox="0 0 16 16" id="icon-feed"><title>feed</title>  <g enable-background="new"> <path d="M2,6v2c3.3,0,6,2.7,6,6h2C10,9.6,6.4,6,2,6z M2,2v2c5.5,0,10,4.5,10,10h2C14,7.4,8.6,2,2,2z M3.5,11C2.7,11,2,11.7,2,12.5S2.7,14,3.5,14S5,13.3,5,12.5S4.3,11,3.5,11z"/> </g> </symbol>
</svg>

	<div id="page" class="site">
		<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
        <div class="header-wrap">
		<header id="masthead" class="site-header" role="banner">
			<div class="header-main">
				<div class="site-branding">
					<h1 class="site-title"><a href="<?php echo site_url();?>" rel="home"><?php echo blog_title();?></a></h1>
					<p class="site-description"><?php echo blog_tagline();?></p>
				</div><!-- .site-branding -->

				<button class="primary-menu-toggle menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<svg class="icon icon-menu" aria-hidden="true" role="img"> <use xlink:href="#menu-toggle"></use> </svg><svg class="icon icon-close" aria-hidden="true" role="img"> <use xlink:href="#menu-close"></use> </svg>		<span class="menu-toggle-text">Menu</span>
				</button>

				<div class="primary-navigation">
					<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Primary Menu">
					<?php echo menu('menu');?>
					</nav><!-- #site-navigation -->
				</div><!-- .primary-navigation -->
			</div><!-- .header-main -->
		</header><!-- #masthead -->
        </div>

        <div class="content-wrap">
	    <div class="site-content" id="messages-div" style='display: none;'><div class="message-alert">...</div></div>
		<div id="content" class="site-content">
			<main id="main" class="site-main" role="main">

				<?php if (!empty($breadcrumb)): ?>
					<div class="breadcrumbs tzwb-clearfix">
						<?php echo $breadcrumb ?>
					</div>
				<?php endif;?>

				<?php if (isset($is_category)):?>
					<header class="entry-header"><h1 class="entry-title"><?php echo i18n('Category');?>: <?php $pageTitle = i18n('Category') . ': ' . $category->title; echo $category->title;?></h1><div class="taxonomy-description"><?php echo $category->body;?></div></header>
				<?php endif;?>
				<?php if (isset($is_tag)):?>
					<header class="entry-header"><h1 class="entry-title"><?php echo i18n('Tags');?>: <?php $pageTitle = i18n('Tags') . ': ' . $tag->title; echo $tag->title;?></h1></header>
				<?php endif;?>
				<?php if (isset($is_archive)):?>
					<header class="entry-header"><h1 class="entry-title"><?php echo i18n('Archives');?>: <?php $pageTitle = i18n('Archives') . ': ' . $archive->title; echo $archive->title;?></h1></header>
				<?php endif;?>
				<?php if (isset($is_search)):?>
					<header class="entry-header"><h1 class="entry-title"><?php echo i18n('Search');?>: <?php $pageTitle = i18n('Search'); echo $search->title;?></h1></header>
				<?php endif;?>
				<?php if (isset($is_type)):?>
					<header class="entry-header"><h1 class="entry-title">Type: <?php echo ucfirst($type->title); $pageTitle = $type->title;?></h1></header>
				<?php endif;?>
				<?php if (isset($is_blog)):?>
					<header class="entry-header"><h1 class="entry-title">Blog</h1><?php $pageTitle = $p->title;?></header>
				<?php endif;?>

				<div id="post-wrapper" class="post-wrapper">
					<?php echo content();?>
				</div>

			</main><!-- #main -->

			<section id="secondary" class="sidebar widget-area" role="complementary">

                <?php if (social()): ?>
				<div id="tzwb-social-icons" class="widget tzwb-social-icons">
					<div class="tzwb-content tzwb-clearfix">
						<?php echo social();?>
					</div>
				</div>
                <?php endif;?>

				<?php if (!isset($is_front) && !isset($is_blog) && theme_config('recent_posts')):?>
				<div id="tzwb-recent-posts" class="widget tzwb-recent-posts">
					<h3 class="widget-title"><?php echo i18n("Recent_posts");?></h3>
					<div class="tzwb-content tzwb-clearfix">
						<?php echo recent_posts();?>
					</div>
				</div>
				<?php endif;?>

				<?php if (config('views.counter') === 'true' && theme_config('popular_posts')) :?>
				<?php if (isset($is_front) || isset($is_blog)):?>
				<div id="tzwb-popular-posts" class="widget tzwb-popular-posts">
					<h3 class="widget-title"><?php echo i18n("Popular_posts");?></h3>
					<div class="tzwb-content tzwb-clearfix">
						<?php echo popular_posts();?>
					</div>
				</div>
				<?php endif;?>
				<?php endif;?>

				<?php if (disqus() && theme_config('recent_comments')): ?>
				<section id="tzwb-recent-comments" class="widget tzwb-recent-comments">
					<h3 class="widget-title"><?php echo i18n('Comments');?></h3>
					<script src="//<?php echo config('disqus.shortname');?>.disqus.com/recent_comments_widget.js?num_items=5&amp;hide_avatars=0&amp;avatar_size=48&amp;excerpt_length=200&amp;hide_mods=0" type="text/javascript"></script><style>li.dsq-widget-item {padding-top:15px;} img.dsq-widget-avatar {margin-right:5px;} ul.dsq-widget-list {padding-left:0px}</style>
				</section>
				<?php endif;?>

				<?php if (local() && theme_config('recent_comments')): ?>
				<section id="tzwb-recent-comments" class="widget tzwb-recent-comments">
					<h3 class="widget-title"><?php echo i18n('Comments');?></h3>
					<ul>
					<?php
					    $comments = getPublishedComments(5);
					    foreach ($comments as $comment) {
					        echo "<li><a href=\"" . site_url() . $comment['url'] . "#" . $comment['id'] . "\">" . $comment['name'] . "</a>";
					        echo "<span><br>" . date(config('date.format'), $comment['timestamp']) . "</span>";
					        echo "<br>" . $comment['comment'] . "</li>";
					    }
					?>
					</ul>
				</section>
				<?php endif;?>


				<?php if (theme_config('webcam')): ?>
				<section id="tzwb-webcam" class="widget tzwb-webcam">
					<h3 class="widget-title"><?php echo i18n('Webcam');?></h3>
					<?php
    					$widget_file = ltrim(parse_url(theme_path(), PHP_URL_PATH), '/') . 'widgets/webcam.php';
                        if (file_exists($widget_file)) {
                            require_once $widget_file;
                        }
					?>
				</section>
				<?php endif;?>

                <?php if (theme_config('category_list') || theme_config('archive_list') || theme_config('tag_cloud')) :?>
				<div id="tzwb-tabbed-content-1" class="widget tzwb-tabbed-content">
					<div class="tzwb-content tzwb-clearfix">
						<div class="tzwb-tabnavi-wrap tzwb-clearfix">
							<ul class="tzwb-tabnavi">
								<?php if (theme_config('category_list')) :?><li><a href="#tzwb-tabbed-content-1-tab-0" class="current-tab"><?php echo i18n('Category');?></a></li><?php endif;?>
								<?php if (theme_config('tag_cloud')) :?><li><a href="#tzwb-tabbed-content-1-tab-1"><?php echo i18n('Tags');?></a></li><?php endif;?>
                                <?php if (theme_config('archive_list')) :?><li><a href="#tzwb-tabbed-content-1-tab-2"><?php echo i18n("Archives");?></a></li><?php endif;?>
							</ul>
						</div>

                        <?php if (theme_config('category_list')) :?>
						<div id="tzwb-tabbed-content-1-tab-0" class="tzwb-tabcontent" style="">
							<div class="tzwb-tabcontent-categories">
                                <?php echo category_list();?>
							</div>
						</div>
                        <?php endif;?>

                        <?php if (theme_config('tag_cloud')) :?>
						<div id="tzwb-tabbed-content-1-tab-1" class="tzwb-tabcontent" style="display: none;">
                            <div class="tzwb-tabcontent-tagcloud widget_tag_cloud">
                                <div class="tagcloud"><?php echo tag_cloud();?></div>
                            </div>
						</div>
                        <?php endif;?>

                        <?php if (theme_config('archive_list')) :?>
						<div id="tzwb-tabbed-content-1-tab-2" class="tzwb-tabcontent" style="display: none;">
						    <ul class="tzwb-tabcontent-archives">
                                <?php echo archive_list('month-year');?>
                            </ul>
						</div>
                        <?php endif;?>

					</div>
				</div>
                <?php endif;?>

				<div id="search-widget" class="widget widget_search">
				<h3 class="widget-title"><?php echo i18n('Search');?></h3>
					<form role="search" class="search-form" >
						<label>
							<span class="screen-reader-text"><?php echo i18n('Search_for');?></span>
							<input type="search" class="search-field" placeholder="<?php echo i18n('Search_for');?> …" name="search" title="<?php echo i18n('Search_for');?>">
						</label>
						<button type="submit" class="search-submit" aria-label="<?php echo i18n('Search');?>">
							<svg class="icon icon-search" aria-hidden="true" role="img"> <use xlink:href="#search"></use> </svg>
							<span class="screen-reader-text"><?php echo i18n('Search');?></span>
						</button>
					</form>
				</div>

			</section><!-- #secondary -->

		</div><!-- #content -->
        </div>

		<div class="footer-wrap">
			<footer id="colophon" class="site-footer">
			<div id="footer-line" class="site-info">
				<style>.credit-link span {text-align:center;font-size:14px;}</style>
				<div class="credit-link">
					<?php echo copyright();?> <span style="float:right;">Design by <a href="https://emidio.reggiani.link/post/ovi-htmly-theme" target="_blank" rel="nofollow">Emidio Reggiani</a></span>
				</div>
			</div>
			</footer><!-- #colophon -->
		</div>

	</div><!-- #page -->

	<script type="text/javascript">
	/* <![CDATA[ */
	var screenReaderText = {"expand":"expand child menu","collapse":"collapse child menu"};
	/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo theme_path();?>js/custom.js" id="custom-js"></script>

    <!-- Javascript to handle system messages calls - actually used for subscribe/unsubscribe -->
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            // Get all URL parameters
            const params = new URLSearchParams(window.location.search);
            
            // Only make the request if there are GET parameters
            if (params.toString()) {
                fetch('themes/ovi/sysmessages.php?' + params.toString())
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.message && data.message.trim() !== '') {
                            // Get DOM elements
                            const messagesDiv = document.getElementById('messages-div');
                            const innerDiv = messagesDiv.querySelector('.message-alert');
                            
                            // Set the message text
                            innerDiv.textContent = data.message;
                            
                            // Reset classes and add the new class
                            innerDiv.className = 'message-alert message-alert-' + data.class;
                            
                            // Show the messages div
                            messagesDiv.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Fetch Error:', error);
                    });
            }
        });
    </script>

    <?php if (strpos($p->body ?? '', '<div class="image-row">') !== false):?>
    
    <style>
        .lightbox {
    position: fixed;
    inset: 0;
    z-index: 9999;
}

.lightbox.hidden {
    display: none;
}

.lightbox-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.85);
}

#lightbox-img {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    max-width: 100vw;
    max-height: 100vh;
    width: auto;
    height: auto;
}

.lightbox-close {
    position: absolute;
    top: 12px;
    right: 18px;
    font-size: 32px;
    color: white;
    background: none;
    border: none;
    cursor: pointer;
}

    </style>
    
    
<div id="lightbox" class="lightbox hidden">
    <div class="lightbox-backdrop"></div>
    <img id="lightbox-img" alt="">
    <button class="lightbox-close">&times;</button>
</div>

    
    
    
    
        <!-- Javascript to handle the image row auto fit - added only if image-row is present in post content -->
        <script type="text/javascript">
            
            
// Lightbox logic
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxBackdrop = lightbox.querySelector('.lightbox-backdrop');
const lightboxClose = lightbox.querySelector('.lightbox-close');

function openLightbox(img) {
    // Use data-original if exists, othewise falls back to src
    const fullSizeSrc = img.dataset.original || img.src;

    // Use natural size but clamp to viewport via CSS max-width/height
    lightboxImg.src = fullSizeSrc;
    lightbox.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    lightbox.classList.add('hidden');
    lightboxImg.src = '';
    document.body.style.overflow = '';
}

lightboxBackdrop.addEventListener('click', closeLightbox);
lightboxClose.addEventListener('click', closeLightbox);

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeLightbox();
});

// Attach click handlers to all images
document.querySelectorAll('.image-row img').forEach(img => {
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => openLightbox(img));
});

            
            
            const containers = document.querySelectorAll('.image-row');
            const mobileBreakpoint = 768; // px
            const gap = 5; // px

            containers.forEach(container => {
                const images = Array.from(container.querySelectorAll('img'));

                function resizeImages() {
                    const isMobile = window.innerWidth <= mobileBreakpoint;

                    if (isMobile) {
                        // Mobile: Process images in pairs and position them
                        let currentTop = 0;

                        for (let i = 0; i < images.length; i += 2) {
                            const rowImages = images.slice(i, Math.min(i + 2, images.length));
                            const rowHeight = resizeImageRow(rowImages, container);

                            // Position images in this row
                            let currentLeft = 0;
                            rowImages.forEach((img, index) => {
                                img.style.position = 'absolute';
                                img.style.top = currentTop + 'px';
                                img.style.left = currentLeft + 'px';
                                currentLeft += parseFloat(img.style.width) + gap;
                            });

                            currentTop += rowHeight + gap;
                        }

                        // Set container height to accommodate all rows
                        container.style.position = 'relative';
                        container.style.height = currentTop - gap + 'px';

                    } else {
                        // Desktop: All images in one row
                        const height = resizeImageRow(images, container);

                        // Reset positioning for desktop
                        images.forEach(img => {
                            img.style.position = 'static';
                            img.style.top = 'auto';
                            img.style.left = 'auto';
                        });

                        container.style.height = 'auto';
                    }
                }

                function resizeImageRow(rowImages, container) {
                    const ratios = rowImages.map(img => img.naturalWidth / img.naturalHeight);
                    const totalRatio = ratios.reduce((a, b) => a + b, 0);
                    const totalGaps = (rowImages.length - 1) * gap;
                    const availableWidth = container.clientWidth - totalGaps;
                    const height = availableWidth / totalRatio;

                    rowImages.forEach((img, index) => {
                        img.style.height = height + 'px';
                        img.style.width = (height * ratios[index]) + 'px';
                    });

                    return height;
                }

                Promise.all(images.map(img => {
                    return new Promise(resolve => {
                        if (img.complete) resolve();
                        else img.onload = resolve;
                    });
                })).then(() => {
                    resizeImages();
                    window.addEventListener('resize', resizeImages);
                });
            });
        </script>
    <?php endif;?>
    
    <?php if (strpos($p->body ?? '', '<pre><code>') !== false):?>
    <script type="text/javascript">
        // highlight code in code blocks
        hljs.highlightAll();

        // add copy button to code blocks
        const copyButtonLabel = "<?php echo i18n('codebtn_copy'); ?>";
        let blocks = document.querySelectorAll("pre:has(code)");

        blocks.forEach((block) => {
            if (navigator.clipboard) {
                let button = document.createElement("button");
                button.className = "btn btn-primary copy-code";
                button.innerHTML = copyButtonLabel;

                block.style.position = "relative"; // Ensure `pre` is positioned
                block.appendChild(button); // Attach the button inside `pre`

                button.addEventListener("click", async () => {
                    await copyCode(block, button);
                });

                // Keep button fixed when scrolling horizontally
                block.addEventListener("scroll", () => {
                    button.style.right = 10 - block.scrollLeft + "px"; // Adjust right offset dynamically
                });
            }
        });

        async function copyCode(block, button) {
            let code = block.querySelector("code");
            let text = code.innerText;
            await navigator.clipboard.writeText(text);

            button.innerText = "<?php echo i18n('codebtn_copied'); ?>";
            setTimeout(() => {
                button.innerHTML = copyButtonLabel;
            }, 700);
        }

        
    </script>
    <?php endif;?>

    <?php if (analytics()): ?><?php echo analytics(); ?><?php endif; ?>
    <?php if (matomo(null, $locals)): ?><?php echo matomo(null, $locals); ?><?php endif; ?>
    
</body>
</html>
